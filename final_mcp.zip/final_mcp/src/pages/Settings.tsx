import { AppShell } from "@/components/shell/AppShell";
import { PageHeader } from "@/components/shell/PageHeader";
import { BackendRequired } from "@/components/shell/BackendRequired";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export default function Settings() {
  return (
    <AppShell>
      <PageHeader
        title="Settings"
        description="Workspace configuration for MCP Command Center."
      />
      <div className="p-6 space-y-4 max-w-[900px]">
        <Card className="p-5 border-border bg-card">
          <h2 className="text-sm font-semibold text-foreground">Workspace</h2>
          <p className="text-[11px] text-muted-foreground">Identification and environment</p>
          <div className="mt-4 grid sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-[11px] uppercase tracking-wider text-muted-foreground">Name</Label>
              <Input defaultValue="MCP Command Center" className="mt-1.5 bg-background" />
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-wider text-muted-foreground">Environment</Label>
              <Input defaultValue="production" className="mt-1.5 bg-background" />
            </div>
          </div>
        </Card>

        <Card className="p-5 border-border bg-card">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-foreground">Persistence</h2>
              <p className="text-[11px] text-muted-foreground">Database, secrets, and message storage</p>
            </div>
            <BackendRequired />
          </div>
          <p className="mt-3 text-[12px] text-muted-foreground">
            Enable Lovable Cloud to store agents, workflows, MCP server registrations, logs, and chat history.
          </p>
        </Card>

        <Card className="p-5 border-border bg-card">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-foreground">AI Gateway</h2>
              <p className="text-[11px] text-muted-foreground">Model provider for AI Chat and agents</p>
            </div>
            <BackendRequired />
          </div>
        </Card>

        <div className="flex justify-end">
          <Button size="sm" disabled>Save changes</Button>
        </div>
      </div>
    </AppShell>
  );
}
