import HyperMCPShell from "@/components/layout/HyperMCPShell";
import { Card } from "@/components/ui/card";
import { Construction } from "lucide-react";

interface HyperMCPStubProps {
  title: string;
  description: string;
}

export default function HyperMCPStub({ title, description }: HyperMCPStubProps) {
  return (
    <HyperMCPShell breadcrumbs={[{ label: title }]}>
      <Card className="p-10 flex flex-col items-center justify-center text-center gap-3 border-dashed">
        <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
          <Construction className="w-5 h-5 text-muted-foreground" />
        </div>
        <h2 className="text-lg font-semibold text-foreground">{title}</h2>
        <p className="text-sm text-muted-foreground max-w-md">{description}</p>
        <p className="text-xs text-muted-foreground/70 mt-2">Coming soon to the HyperMCP workspace.</p>
      </Card>
    </HyperMCPShell>
  );
}
