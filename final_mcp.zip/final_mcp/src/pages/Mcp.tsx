import { AppShell } from "@/components/shell/AppShell";
import { PageHeader } from "@/components/shell/PageHeader";
import { BackendRequiredCard } from "@/components/shell/BackendRequired";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function Mcp() {
  return (
    <AppShell>
      <PageHeader
        title="MCP Servers"
        description="Model Context Protocol servers registered as tool sources."
        actions={
          <Button size="sm" className="gap-2">
            <Plus className="h-3.5 w-3.5" /> Register Server
          </Button>
        }
      />
      <div className="p-6 space-y-4 max-w-[1400px]">
        <Card className="p-0 border-border bg-card overflow-hidden">
          <div className="px-5 py-3 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground">Server Registry</h2>
            <p className="text-[11px] text-muted-foreground">URL, transport, auth, exposed tools</p>
          </div>
          <div className="p-5">
            <BackendRequiredCard
              title="No MCP servers registered"
              description="Add an MCP server URL and authentication to make its tools available to agents."
            />
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
