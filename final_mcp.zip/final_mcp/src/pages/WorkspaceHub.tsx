import { useEffect, useState, useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import SiteShell from "@/components/layout/SiteShell";
import PortalAuthForm from "@/components/auth/PortalAuthForm";
import { LogOut, Bell, Headset, Users, Shield, Sparkles, Truck, Megaphone, Palette, Cpu, BrainCircuit } from "lucide-react";
import logoImg from "@/assets/logo.png";
import PortalCard from "@/components/portal/PortalCard";
import { useAgentProfile } from "@/hooks/useAgentProfile";
import { useNotifications } from "@/hooks/useNotifications";
import { useUserRoles } from "@/hooks/useUserRoles";
import { useAuthSession } from "@/hooks/useAuthSession";
import { motion } from "framer-motion";
import type { Database } from "@/integrations/supabase/types";

import AgentToolWorkspace from "@/components/agent/AgentToolWorkspace";
import GreenParticles from "@/components/portal/GreenParticles";

type AppRole = Database["public"]["Enums"]["app_role"];

const STORAGE_KEY = "truemove_remembered_role";
function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

const PORTALS: { key: string; label: string; description: string; href: string; icon: any; accentHsl: string; requiredRoles: AppRole[]; beta?: boolean }[] = [
  {
    key: "agents",
    label: "Agents",
    description: "Dialer, pipeline, customers & operations",
    href: "/agent/dashboard",
    icon: Headset,
    accentHsl: "142 71% 45%",
    requiredRoles: ["agent"],
  },
  {
    key: "managers",
    label: "Managers",
    description: "Team dashboards, coaching & oversight",
    href: "/manager/dashboard",
    icon: Users,
    accentHsl: "217 91% 60%",
    requiredRoles: ["manager"],
  },
  {
    key: "admin",
    label: "Admin / Owner",
    description: "Accounting, expenses, invoices, vendors, payroll, compliance & settings",
    href: "/admin/dashboard",
    icon: Shield,
    accentHsl: "38 92% 50%",
    requiredRoles: ["admin", "owner"],
  },
  {
    key: "dispatch",
    label: "Dispatch",
    description: "Fleet tracking, driver assignments, route management & scheduling",
    href: "/dispatch/dashboard",
    icon: Truck,
    accentHsl: "262 83% 58%",
    requiredRoles: ["agent", "manager"],
  },
  {
    key: "creative",
    label: "Creative Studio",
    description: "Website builder, landing pages, AI images & media library",
    href: "/creative/studio",
    icon: Palette,
    accentHsl: "280 70% 55%",
    requiredRoles: ["command_center", "admin"],
  },
  {
    key: "hypermcp",
    label: "HyperMCP",
    description: "Model Context Protocol control center for agents & integrations",
    href: "/hypermcp",
    icon: Cpu,
    accentHsl: "190 95% 50%",
    requiredRoles: ["admin"],
  },
  {
    key: "llm",
    label: "LLM Hub",
    description: "Direct chat with Claude, GPT-5 & Gemini · MCP-ready",
    href: "/llm",
    icon: BrainCircuit,
    accentHsl: "25 95% 55%",
    requiredRoles: ["admin", "manager", "agent"],
  },
  {
    key: "marketing",
    label: "Marketing",
    description: "Campaigns, landing pages, A/B tests & marketing analytics",
    href: "/marketing/dashboard",
    icon: Megaphone,
    accentHsl: "330 90% 55%",
    requiredRoles: ["marketing", "admin"],
  },
  {
    key: "commandcenter",
    label: "Command Center",
    description: "Growth, SEO, advertising & automation control center",
    href: "/commandcenter",
    icon: Sparkles,
    accentHsl: "190 95% 50%",
    requiredRoles: ["admin", "command_center"],
  },
];

export default function AgentLogin() {
  const navigate = useNavigate();
  const location = useLocation();
  const { session, loading } = useAuthSession();

  const { isOwner, hasAnyRole, loading: rolesLoading } = useUserRoles();
  const [workspaceOpen, setWorkspaceOpen] = useState(false);
  const { displayName } = useAgentProfile();
  const { unreadCount } = useNotifications();
  const greeting = useMemo(() => getGreeting(), []);

  // After login + roles resolve, restore the page the user was trying to reach
  useEffect(() => {
    if (loading || rolesLoading || !session) return;
    const state = location.state as { from?: { pathname: string; search?: string } } | null;
    const target = state?.from?.pathname;
    if (target && target !== "/dashboard") {
      navigate(target + (state?.from?.search || ""), { replace: true });
    }
  }, [loading, rolesLoading, session, location.state, navigate]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem(STORAGE_KEY);
  };

  // Shared page wrapper with shimmery gray bg + particles
  const PageShell = ({ children }: { children: React.ReactNode }) => (
    <SiteShell centered backendMode hideHeader>
      <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[hsl(220,10%,92%)] via-[hsl(220,8%,88%)] to-[hsl(220,12%,85%)]">
        {/* Shimmery metallic sheen overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,_hsla(220,15%,98%,0.4)_0%,_transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_80%,_hsla(142,30%,90%,0.2)_0%,_transparent_50%)]" />
        <GreenParticles />
        <div className="relative z-10">
          {children}
        </div>
      </div>
    </SiteShell>
  );

  // Don't render anything while checking auth — prevents flash/flicker
  if (loading) {
    return (
      <PageShell>
        <div className="flex items-center justify-center min-h-screen">
          <img src={logoImg} alt="TruMove" className="h-8 opacity-60" />
        </div>
      </PageShell>
    );
  }

  if (!session) {
    return (
      <PageShell>
        <div className="flex items-center justify-center min-h-screen px-4 py-16">
          <PortalAuthForm onAuthenticated={() => {}} />
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="flex flex-col items-center justify-center min-h-screen px-4 py-20">

        {/* Header */}
        <div className="flex flex-col items-center gap-1.5 mb-16">
          <img src={logoImg} alt="TruMove" className="h-7" />
          <h1 className="text-lg font-semibold tracking-tight text-foreground mt-2 flex items-center gap-2">
            {greeting}, {displayName}
            {unreadCount > 0 && (
              <span className="inline-flex items-center gap-1 bg-destructive text-destructive-foreground rounded-full px-1.5 py-0.5 text-[9px] font-semibold">
                <Bell className="w-2.5 h-2.5" />
                {unreadCount}
              </span>
            )}
          </h1>
          <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
            <span>{session.user.email}</span>
            <span className="text-border">·</span>
            <button
              onClick={handleSignOut}
              className="inline-flex items-center gap-1 hover:text-destructive transition-colors"
            >
              <LogOut className="w-3 h-3" /> Sign out
            </button>
          </div>
        </div>

        {/* Portal cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 w-full max-w-6xl">
          {PORTALS.map((portal, i) => {
            const allowed = isOwner || hasAnyRole(...portal.requiredRoles as AppRole[]);
            return (
              <PortalCard
                key={portal.key}
                label={portal.label}
                description={portal.description}
                icon={portal.icon}
                accentHsl={portal.accentHsl}
                index={i}
                disabled={!rolesLoading && !allowed}
                beta={portal.beta}
                onClick={() => {
                  navigate(portal.key === "agents" ? "/agent/dashboard" : portal.href);
                }}
              />
            );
          })}
        </div>

        
      </div>
    </PageShell>
  );
}
