import { AppShell } from "@/components/shell/AppShell";
import { PageHeader } from "@/components/shell/PageHeader";
import { BackendRequiredCard } from "@/components/shell/BackendRequired";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function Workflows() {
  return (
    <AppShell>
      <PageHeader
        title="Workflows"
        description="Multi-step orchestration chains across agents, tools, and MCP servers."
        actions={
          <Button size="sm" className="gap-2">
            <Plus className="h-3.5 w-3.5" /> New Workflow
          </Button>
        }
      />
      <div className="p-6 space-y-4 max-w-[1400px]">
        <Card className="p-0 border-border bg-card overflow-hidden">
          <div className="px-5 py-3 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground">Workflow Catalog</h2>
            <p className="text-[11px] text-muted-foreground">Templates, triggers, last execution</p>
          </div>
          <div className="p-5">
            <BackendRequiredCard
              title="No workflows defined"
              description="Workflows will appear here once the orchestration engine is wired."
            />
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
