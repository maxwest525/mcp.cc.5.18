import { AppShell } from "@/components/shell/AppShell";
import { PageHeader } from "@/components/shell/PageHeader";
import { BackendRequiredCard } from "@/components/shell/BackendRequired";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

export default function Logs() {
  return (
    <AppShell>
      <PageHeader
        title="Logs"
        description="Routing, agent, workflow, and webhook event logs."
        actions={
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="h-3.5 w-3.5" /> Export
          </Button>
        }
      />
      <div className="p-6 space-y-4 max-w-[1400px]">
        <Card className="p-0 border-border bg-card overflow-hidden">
          <div className="px-5 py-3 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground">Event Stream</h2>
            <p className="text-[11px] text-muted-foreground">Timestamp, source, level, message</p>
          </div>
          <div className="p-5">
            <BackendRequiredCard
              title="No events yet"
              description="Logs will appear once the event bus and log sink are wired."
            />
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
