import { useState, useRef, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import SiteShell from "@/components/layout/SiteShell";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Send, Cpu, MessageSquare, Loader2, Sparkles, Plus, Trash2, Pencil, Check, X } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import MCPConnectionsPanel from "@/components/llm/MCPConnectionsPanel";
import { cn } from "@/lib/utils";

const MODELS: { value: string; label: string; group: string }[] = [
  // Anthropic (direct API)
  { value: "claude-sonnet-4-5-20250929", label: "Claude Sonnet 4.5", group: "Anthropic" },
  { value: "claude-opus-4-5-20250929", label: "Claude Opus 4.5", group: "Anthropic" },
  { value: "claude-haiku-4-5-20250929", label: "Claude Haiku 4.5", group: "Anthropic" },
  // Google (Lovable AI Gateway)
  { value: "google/gemini-3.1-pro-preview", label: "Gemini 3.1 Pro (Preview)", group: "Google" },
  { value: "google/gemini-3-flash-preview", label: "Gemini 3 Flash (Preview)", group: "Google" },
  { value: "google/gemini-2.5-pro", label: "Gemini 2.5 Pro", group: "Google" },
  { value: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash", group: "Google" },
  { value: "google/gemini-2.5-flash-lite", label: "Gemini 2.5 Flash Lite", group: "Google" },
  // OpenAI (Lovable AI Gateway)
  { value: "openai/gpt-5", label: "GPT-5", group: "OpenAI" },
  { value: "openai/gpt-5-mini", label: "GPT-5 Mini", group: "OpenAI" },
  { value: "openai/gpt-5-nano", label: "GPT-5 Nano", group: "OpenAI" },
  { value: "openai/gpt-5.2", label: "GPT-5.2", group: "OpenAI" },
];

interface Msg { id?: string; role: "user" | "assistant"; content: string; model?: string }
interface Thread { id: string; title: string; model: string; updated_at: string }

export default function LLMHub() {
  const navigate = useNavigate();
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [model, setModel] = useState(MODELS[0].value);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
  }, []);

  const loadThreads = useCallback(async () => {
    const { data, error } = await supabase
      .from("llm_threads")
      .select("id,title,model,updated_at")
      .order("updated_at", { ascending: false });
    if (error) { toast.error(error.message); return; }
    setThreads(data ?? []);
    return data ?? [];
  }, []);

  useEffect(() => { if (userId) loadThreads(); }, [userId, loadThreads]);

  const loadMessages = useCallback(async (threadId: string) => {
    const { data, error } = await supabase
      .from("llm_messages")
      .select("id,role,content,model")
      .eq("thread_id", threadId)
      .order("created_at", { ascending: true });
    if (error) { toast.error(error.message); return; }
    setMessages((data ?? []).filter((m: any) => m.role !== "system") as Msg[]);
  }, []);

  const selectThread = async (t: Thread) => {
    setActiveId(t.id);
    setModel(t.model);
    await loadMessages(t.id);
  };

  const newThread = () => {
    setActiveId(null);
    setMessages([]);
    setInput("");
  };

  const deleteThread = async (id: string) => {
    const { error } = await supabase.from("llm_threads").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    setThreads((prev) => prev.filter((t) => t.id !== id));
    if (activeId === id) newThread();
  };

  const renameThread = async (id: string) => {
    const title = editTitle.trim() || "Untitled";
    const { error } = await supabase.from("llm_threads").update({ title }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    setThreads((prev) => prev.map((t) => (t.id === id ? { ...t, title } : t)));
    setEditingId(null);
  };

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading || !userId) return;
    setLoading(true);
    setInput("");

    let threadId = activeId;
    try {
      if (!threadId) {
        const title = text.slice(0, 60);
        const { data, error } = await supabase
          .from("llm_threads")
          .insert({ user_id: userId, title, model })
          .select("id,title,model,updated_at")
          .single();
        if (error) throw error;
        threadId = data.id;
        setActiveId(threadId);
        setThreads((prev) => [data as Thread, ...prev]);
      } else {
        // sync model on existing thread
        await supabase.from("llm_threads").update({ model }).eq("id", threadId);
      }

      const userMsg: Msg = { role: "user", content: text };
      const next = [...messages, userMsg];
      setMessages(next);

      await supabase.from("llm_messages").insert({
        thread_id: threadId, user_id: userId, role: "user", content: text,
      });

      const { data, error } = await supabase.functions.invoke("llm-chat", {
        body: {
          model,
          messages: next.map((m) => ({ role: m.role, content: m.content })),
          system: "You are a helpful assistant inside the TruMove operations platform.",
        },
      });
      if (error) throw error;
      if (!data?.ok) throw new Error(data?.error ?? "LLM error");

      const reply: Msg = { role: "assistant", content: data.reply, model };
      setMessages((prev) => [...prev, reply]);

      await supabase.from("llm_messages").insert({
        thread_id: threadId, user_id: userId, role: "assistant", content: data.reply, model,
      });
      await supabase.from("llm_threads").update({ updated_at: new Date().toISOString() }).eq("id", threadId);
      loadThreads();
    } catch (e: any) {
      toast.error(e.message ?? "Request failed");
      setMessages((prev) => [...prev, { role: "assistant", content: `⚠️ ${e.message ?? e}`, model }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SiteShell hideHeader backendMode>
      <div className="min-h-screen bg-background">
        <div className="border-b border-border bg-card/50 backdrop-blur sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary" />
                <h1 className="text-base font-semibold">LLM Hub</h1>
              </div>
            </div>
            <div className="text-xs text-muted-foreground hidden sm:block">
              Direct chat with frontier models · MCP-ready
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 py-6">
          <Tabs defaultValue="chat" className="w-full">
            <TabsList>
              <TabsTrigger value="chat" className="gap-2"><MessageSquare className="w-4 h-4" />Chat</TabsTrigger>
              <TabsTrigger value="mcp" className="gap-2"><Cpu className="w-4 h-4" />MCP Connections</TabsTrigger>
            </TabsList>

            <TabsContent value="chat" className="mt-4">
              <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-4 h-[calc(100vh-220px)]">
                {/* Threads sidebar */}
                <Card className="flex flex-col overflow-hidden">
                  <div className="p-2 border-b border-border">
                    <Button onClick={newThread} className="w-full justify-start gap-2" size="sm" variant="outline">
                      <Plus className="w-4 h-4" /> New chat
                    </Button>
                  </div>
                  <div className="flex-1 overflow-y-auto p-1">
                    {threads.length === 0 && (
                      <div className="text-xs text-muted-foreground text-center p-4">
                        No conversations yet
                      </div>
                    )}
                    {threads.map((t) => (
                      <div
                        key={t.id}
                        className={cn(
                          "group rounded-md px-2 py-2 text-sm cursor-pointer flex items-center gap-2 hover:bg-muted",
                          activeId === t.id && "bg-muted"
                        )}
                        onClick={() => editingId !== t.id && selectThread(t)}
                      >
                        {editingId === t.id ? (
                          <>
                            <input
                              autoFocus
                              value={editTitle}
                              onChange={(e) => setEditTitle(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") renameThread(t.id);
                                if (e.key === "Escape") setEditingId(null);
                              }}
                              className="flex-1 bg-background border border-border rounded px-1 py-0.5 text-xs"
                            />
                            <button onClick={(e) => { e.stopPropagation(); renameThread(t.id); }}>
                              <Check className="w-3.5 h-3.5 text-green-600" />
                            </button>
                            <button onClick={(e) => { e.stopPropagation(); setEditingId(null); }}>
                              <X className="w-3.5 h-3.5 text-muted-foreground" />
                            </button>
                          </>
                        ) : (
                          <>
                            <MessageSquare className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="truncate text-xs font-medium">{t.title}</div>
                              <div className="text-[10px] text-muted-foreground truncate">
                                {MODELS.find((m) => m.value === t.model)?.label ?? t.model.split("/").pop()}
                              </div>
                            </div>
                            <button
                              className="opacity-0 group-hover:opacity-100 transition"
                              onClick={(e) => { e.stopPropagation(); setEditingId(t.id); setEditTitle(t.title); }}
                            >
                              <Pencil className="w-3 h-3 text-muted-foreground hover:text-foreground" />
                            </button>
                            <button
                              className="opacity-0 group-hover:opacity-100 transition"
                              onClick={(e) => { e.stopPropagation(); deleteThread(t.id); }}
                            >
                              <Trash2 className="w-3 h-3 text-muted-foreground hover:text-destructive" />
                            </button>
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Chat area */}
                <Card className="flex flex-col overflow-hidden">
                  <div className="border-b border-border px-4 py-2 flex items-center gap-3 bg-muted/30">
                    <span className="text-xs text-muted-foreground">Model</span>
                    <Select value={model} onValueChange={setModel}>
                      <SelectTrigger className="h-8 w-[260px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MODELS.map((m) => (
                          <SelectItem key={m.value} value={m.value}>
                            <span className="text-xs text-muted-foreground mr-2">{m.group}</span>
                            {m.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {activeId && (
                      <span className="ml-auto text-xs text-muted-foreground truncate max-w-[40%]">
                        {threads.find((t) => t.id === activeId)?.title}
                      </span>
                    )}
                  </div>

                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.length === 0 && (
                      <div className="h-full flex flex-col items-center justify-center text-center text-muted-foreground">
                        <Sparkles className="w-8 h-8 mb-3 opacity-40" />
                        <p className="text-sm">Start a conversation with any frontier model.</p>
                        <p className="text-xs mt-1">Threads save automatically · switch models per thread</p>
                      </div>
                    )}
                    {messages.map((m, i) => (
                      <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                        <div className={`max-w-[85%] rounded-xl px-4 py-2.5 text-sm ${
                          m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"
                        }`}>
                          {m.role === "assistant" ? (
                            <div className="prose prose-sm dark:prose-invert max-w-none">
                              <ReactMarkdown>{m.content}</ReactMarkdown>
                            </div>
                          ) : (
                            <div className="whitespace-pre-wrap">{m.content}</div>
                          )}
                          {m.model && (
                            <div className="mt-1 text-[10px] opacity-60">{m.model.split("/").pop()}</div>
                          )}
                        </div>
                      </div>
                    ))}
                    {loading && (
                      <div className="flex justify-start">
                        <div className="bg-muted rounded-xl px-4 py-2.5 text-sm flex items-center gap-2">
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span className="text-xs text-muted-foreground">Thinking…</span>
                        </div>
                      </div>
                    )}
                    <div ref={endRef} />
                  </div>

                  <div className="border-t border-border p-3 bg-card">
                    <div className="flex items-end gap-2">
                      <Textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault();
                            send();
                          }
                        }}
                        placeholder="Message the model… (Shift+Enter for newline)"
                        className="min-h-[44px] max-h-40 resize-none"
                        autoFocus
                      />
                      <Button onClick={send} disabled={!input.trim() || loading}>
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="mcp" className="mt-4">
              <MCPConnectionsPanel />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </SiteShell>
  );
}
